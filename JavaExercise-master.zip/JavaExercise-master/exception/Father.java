package exception;

public class Father {
    public void showInfo(Object message) throws NullPointerException{
        System.out.println(message);
    }

}
