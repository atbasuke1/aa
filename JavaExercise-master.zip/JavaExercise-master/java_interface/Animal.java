package java_interface;

import java.io.Serializable;
import java.util.Collection;

public interface Animal {
    void move();
    void eat();
    void sleep();
}
